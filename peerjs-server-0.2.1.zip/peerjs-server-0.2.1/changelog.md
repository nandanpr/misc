# PeerServer Changelog

### 0.2.1

* Added test suite.
* Locked node dependency for restify.
